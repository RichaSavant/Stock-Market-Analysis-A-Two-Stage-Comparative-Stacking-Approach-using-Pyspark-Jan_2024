ssh aj2529@prince.hpc.nyu.edu "module load pyspark/python3.6/2.2.0; python3 finalStockPrediction.py;"
